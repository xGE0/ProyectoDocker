from flask import Flask, request, jsonify
from flask_cors import CORS
import psycopg2
import os
from datetime import datetime
import hashlib
import re

app = Flask(__name__)
CORS(app)

def get_connection():
    return psycopg2.connect(
        dbname=os.getenv("DB_NAME", "notas"),
        user=os.getenv("DB_USER", "notas_user"),
        password=os.getenv("DB_PASSWORD", "notas_password"),
        host=os.getenv("DB_HOST", "db"),
        port=os.getenv("DB_PORT", "5432"),
        options='-c client_encoding=UTF8'
    )

@app.route('/')
def index():
    return "API de Notas corriendo 🚀"

@app.route('/register', methods=['POST'])
def register():
    data = request.get_json()
    username = data.get("username")
    password = data.get("password")

    if not username or not password:
        return jsonify({"error": "Faltan campos"}), 400

    if not re.match(r'^[a-zA-Z0-9_]{3,20}$', username):
        return jsonify({"error": "Nombre de usuario inválido"}), 400

    hashed_pw = hashlib.sha256(password.encode()).hexdigest()

    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("INSERT INTO usuarios (username, password) VALUES (%s, %s)", (username, hashed_pw))
        conn.commit()
        cur.close()
        conn.close()
        print(f"✅ Usuario registrado: {username}")
        return jsonify({"mensaje": "Usuario registrado"}), 201
    except Exception as e:
        print("❌ Error en registro:", e)
        return jsonify({"error": "Error en el servidor"}), 500

@app.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data.get("username")
    password = data.get("password")

    if not username or not password:
        return jsonify({"error": "Faltan campos"}), 400

    hashed_pw = hashlib.sha256(password.encode()).hexdigest()

    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT id FROM usuarios WHERE username = %s AND password = %s", (username, hashed_pw))
        result = cur.fetchone()
        cur.close()
        conn.close()

        if result:
            print(f"✅ Login exitoso: {username}")
            return jsonify({"mensaje": "Login exitoso", "usuario_id": result[0]}), 200
        else:
            print(f"❌ Login fallido: {username}")
            return jsonify({"error": "Credenciales incorrectas"}), 401
    except Exception as e:
        print("❌ Error en login:", e)
        return jsonify({"error": "Error en el servidor"}), 500

@app.route('/notas', methods=['GET'])
def get_notas():
    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute('SELECT * FROM notas')
        result = cur.fetchall()
        cur.close()
        conn.close()

        return jsonify([{
            "id": r[0],
            "nombre": r[1],
            "fecha": r[2].isoformat() if isinstance(r[2], datetime) else str(r[2]),
            "descripcion": r[3],
            "usuario_id": r[4]
        } for r in result])
    except Exception as e:
        print("❌ Error en GET /notas:", e)
        return jsonify({"error": "Error en el servidor"}), 500

@app.route('/notas', methods=['POST'])
def crear_nota():
    data = request.get_json()
    nombre = data.get('nombre')
    fecha = data.get('fecha')
    descripcion = data.get('descripcion')
    usuario_id = data.get('usuario_id', 1)

    if not nombre or not fecha or not descripcion:
        return jsonify({"error": "Faltan campos"}), 400

    # Validar que usuario_id sea numérico
    try:
        usuario_id = int(usuario_id)
    except ValueError:
        return jsonify({"error": "ID de usuario inválido"}), 400

    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute('INSERT INTO notas (nombre, fecha, descripcion, usuario_id) VALUES (%s, %s, %s, %s)',
                    (nombre, fecha, descripcion, usuario_id))
        conn.commit()
        cur.close()
        conn.close()
        print(f"📝 Nota creada por usuario {usuario_id}: {nombre}")
        return jsonify({"mensaje": "Nota creada"}), 201
    except Exception as e:
        print("❌ Error en POST /notas:", e)
        return jsonify({"error": "Error en el servidor"}), 500

if __name__ == '__main__':
    print("🚀 Iniciando API de Notas en http://localhost:5000")
    app.run(host='0.0.0.0', port=5000, debug=True)
