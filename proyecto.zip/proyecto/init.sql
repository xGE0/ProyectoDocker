CREATE TABLE IF NOT EXISTS usuarios (
    id SERIAL PRIMARY KEY,
    username VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(100) NOT NULL
);

CREATE TABLE IF NOT EXISTS notas (
    id SERIAL PRIMARY KEY,
    nombre VARCHAR(255),
    fecha DATE,
    descripcion TEXT,
    usuario_id INTEGER REFERENCES usuarios(id)
);
