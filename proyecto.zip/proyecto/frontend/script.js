document.addEventListener("DOMContentLoaded", function () {
    const crearNotaBtn = document.getElementById('crearNotaBtn');
    const modal = document.getElementById('modal');
    const closeBtn = document.getElementById('closeBtn');
    const notaForm = document.getElementById('notaForm');
    const nombreInput = document.getElementById('nombre');
    const fechaInput = document.getElementById('fecha');
    const descripcionInput = document.getElementById('descripcion');
    const notasContainer = document.getElementById('notas-container');
    const authForm = document.getElementById('authForm');
    const registerBtn = document.getElementById('registerBtn');
    const logoutBtn = document.getElementById('logoutBtn');

    // Inicial: ocultar todo lo privado
    crearNotaBtn.style.display = "none";
    modal.style.display = "none";
    logoutBtn.style.display = "none";
    notasContainer.style.display = "none";

    const usuario_id = localStorage.getItem("usuario_id");
    const usuario_nombre = localStorage.getItem("usuario_nombre");

    // Si hay sesión activa
    if (usuario_id && usuario_nombre) {
        mostrarElementosPrivados();
        fetchNotas();
    }

    // Mostrar modal para nota
    crearNotaBtn.addEventListener('click', () => modal.style.display = "block");
    closeBtn.addEventListener('click', () => modal.style.display = "none");

    // Cerrar sesión
    logoutBtn.addEventListener("click", () => {
        localStorage.clear();
        location.reload();
    });

    // Registrar usuario
    registerBtn.addEventListener('click', () => {
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;

        if (!username || !password) return alert("Rellena ambos campos");

        fetch("http://localhost:5000/register", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ username, password })
        })
        .then(res => res.json())
        .then(data => {
            alert("✅ Registro exitoso");
        });
    });

    // Login
    authForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;

        fetch("http://localhost:5000/login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ username, password })
        })
        .then(res => res.json())
        .then(data => {
            if (data.usuario_id) {
                localStorage.setItem("usuario_id", data.usuario_id);
                localStorage.setItem("usuario_nombre", username);
                alert(`Bienvenido, ${username}`);
                mostrarElementosPrivados();
                fetchNotas();
            } else {
                alert("❌ Usuario o contraseña incorrectos");
            }
        });
    });

    // Crear nota
    notaForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const usuario_id = localStorage.getItem("usuario_id");
        if (!usuario_id) return alert("Primero inicia sesión.");

        const nuevaNota = {
            nombre: nombreInput.value,
            fecha: fechaInput.value,
            descripcion: descripcionInput.value,
            usuario_id: parseInt(usuario_id)
        };

        fetch('http://localhost:5000/notas', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(nuevaNota)
        })
        .then(res => res.json())
        .then(data => {
            if (data.mensaje) {
                alert('✅ Nota guardada');
                notaForm.reset();
                modal.style.display = "none";
                fetchNotas();
            } else {
                alert("❌ Error al guardar la nota");
            }
        })
        .catch(err => {
            alert("Error en el servidor");
            console.error(err);
        });
    });

    // Mostrar notas del usuario
    function fetchNotas() {
        fetch('http://localhost:5000/notas')
        .then(res => res.json())
        .then(data => {
            notasContainer.innerHTML = "";
            const username = localStorage.getItem("usuario_nombre");

            const userNotas = data.filter(n => n.usuario_id == localStorage.getItem("usuario_id"));

            if (userNotas.length === 0) {
                notasContainer.innerHTML = `<p>No hay notas aún.</p>`;
            } else {
                userNotas.forEach(nota => {
                    const div = document.createElement('div');
                    div.className = 'nota';
                    div.innerHTML = `<h3>${nota.nombre}</h3><p>${nota.descripcion}</p><small>${nota.fecha}</small>`;
                    notasContainer.appendChild(div);
                });
            }
        });
    }

    // Mostrar todo lo que corresponde al usuario logueado
    function mostrarElementosPrivados() {
        crearNotaBtn.style.display = "inline-block";
        logoutBtn.style.display = "inline-block";
        notasContainer.style.display = "block";
        authForm.style.display = "none";
    }
});
